package pe.edu.upc.demo.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.demo.entities.Administrator;
import pe.edu.upc.demo.repositories.IAdministratorRepository;
import pe.edu.upc.demo.serviceinterfaces.IAdministratorService;

@Service
public class AdministratorServiceImpl implements IAdministratorService{

	@Autowired
	private IAdministratorRepository adminRepository;
	
	@Override
	public void insert(Administrator admin) {
		// TODO Auto-generated method stub
		adminRepository.save(admin);
	}

	@Override
	public List<Administrator> list() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();
	}

	@Override
	public void delete(int idAdministrador) {
		// TODO Auto-generated method stub
		adminRepository.deleteById(idAdministrador);
	}

	@Override
	public Optional<Administrator> listId(int idAdministrador) {
		// TODO Auto-generated method stub
		return adminRepository.findById(idAdministrador);
	}

	@Override
	public void update(Administrator admin) {
		// TODO Auto-generated method stub
		adminRepository.save(admin);
	}

}

package pe.edu.upc.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Administrator")
public class Administrator {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idAdministrador;
	
	@Column(name="userAdmin", length = 25, nullable = false)
	private String userAdmin;
	
	@Column(name="userPassword", length = 20, nullable = false)
	private String userPassword;

	public Administrator() {
		super();
		//TODO Auto-generated constructor stub
	}

	public Administrator(int idAdministrador, String userAdmin, String userPassword) {
		super();
		this.idAdministrador = idAdministrador;
		this.userAdmin = userAdmin;
		this.userPassword = userPassword;
	}

	public int getIdAdministrador() {
		return idAdministrador;
	}

	public void setIdAdministrador(int idAdministrador) {
		this.idAdministrador = idAdministrador;
	}

	public String getUserAdmin() {
		return userAdmin;
	}

	public void setUserAdmin(String userAdmin) {
		this.userAdmin = userAdmin;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
}

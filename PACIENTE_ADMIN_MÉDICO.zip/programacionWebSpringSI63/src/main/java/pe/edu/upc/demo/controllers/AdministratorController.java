package pe.edu.upc.demo.controllers;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.demo.entities.Administrator;
import pe.edu.upc.demo.serviceinterfaces.IAdministratorService;

@Controller
@RequestMapping("/aadmins")
public class AdministratorController {

	@Autowired
	private IAdministratorService adminService;
	
	@GetMapping("/new")
	public String newAdmin(Model model) {
		model.addAttribute("a", new Administrator());
		return "administrator/frmRegistro";
	}
	
	@PostMapping("/save")
	public String saveAdmin(@Validated Administrator ad, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "administrator/frmRegistro";
		}else {
			adminService.insert(ad);
			model.addAttribute("mensaje", "Se registro correctamente");
			return "redirect:/aadmins/new";
		}
	}
	
	@GetMapping("/list")
	public String listAdmin(Model model) {
		try {
			model.addAttribute("listaAdministradores", adminService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "/administrator/frmLista";
	}
	
	@RequestMapping("/delete")
	public String delete(Map<String, Object> model, @RequestParam(value= "id") Integer id) { 
		try {
			if (id!=null && id>0) {
				adminService.delete(id);
				model.put("listaAdministradores", adminService.list());
			}
		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "administrator/frmLista";
	}
	
	// va a llevar el objetivo y lo va mostrar en el formulario 
	@RequestMapping("/goupdate/{id}")
	public String goUpdateAdmin(@PathVariable int id, Model model) {
		Optional<Administrator>objAdm=adminService.listId(id);
		model.addAttribute("ad", objAdm.get());
		return "administrator/frmActualiza";
	}
	
	//guardar los cambios
	@RequestMapping("/update")
	public String updateAdmin(Administrator a) {
		adminService.update(a);
		return "redirect:/aadmins/list";
	}
}

package pe.edu.upc.demo.serviceinterfaces;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.demo.entities.Administrator;

public interface IAdministratorService {

	public void insert(Administrator admin);
	
	public List<Administrator> list();
	
	public void delete(int idAdministrador);
	
	Optional<Administrator> listId(int idAdministrador);
	
	public void update(Administrator admin);
	
}
